# Frontend (Vite + React + ethers, for Ganache)
## Quick Start
1) In `../backend`: deploy the contract on Ganache and copy the artifact
2) In this folder:
```bash
npm install
cp ./src/lib/FileRegistry.artifact.json ./src/lib/FileRegistry.artifact.json # ensure exists
# Set contract address:
cp .env.example .env
# edit .env and set VITE_REGISTRY_ADDRESS=0x... (from deploy output)
npm run dev
```
Open http://localhost:5173
Connect MetaMask (Ganache network) and use the app.
