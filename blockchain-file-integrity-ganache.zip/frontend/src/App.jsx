import { useState } from "react";
import { sha256File } from "./lib/hash.js";
import { getContract } from "./lib/contract.js";
import artifact from "./lib/FileRegistry.artifact.json";

const CONTRACT = import.meta.env.VITE_REGISTRY_ADDRESS;

export default function App(){
  const [file,setFile]=useState(null);
  const [hash,setHash]=useState("");
  const [status,setStatus]=useState("");
  const [rec,setRec]=useState(null);

  const doHash=async()=>{
    if(!file){ setStatus("Choose a file first"); return; }
    setStatus("Hashing...");
    const h = await sha256File(file);
    setHash(h);
    setStatus("Hash ready");
  };

  const doRegister=async()=>{
    try{
      setStatus("Connecting...");
      const c = await getContract(CONTRACT, artifact.abi);
      setStatus("Sending transaction...");
      const tx = await c.registerFile(hash, file?.name || "", "");
      await tx.wait();
      setStatus("Registered on local chain ✅");
    }catch(e){ setStatus(e.reason || e.message); }
  };

  const doVerify=async()=>{
    try{
      setStatus("Checking...");
      const c = await getContract(CONTRACT, artifact.abi);
      const exists = await c.isRegistered(hash);
      if(!exists){ setStatus("NOT REGISTERED ❌"); setRec(null); return; }
      const r = await c.getRecord(hash);
      const data = { owner:r[0], timestamp: Number(r[1]), filename:r[2], note:r[3], txHint:r[4] };
      setRec(data);
      setStatus("REGISTERED ✅");
    }catch(e){ setStatus(e.reason || e.message); }
  };

  return <div style={{padding:24, maxWidth:840, margin:"0 auto"}}>
    <h1>Local Blockchain File Integrity (Ganache)</h1>
    <p>Hash locally → store on Ganache → verify anytime.</p>

    <div style={{background:"#fff",padding:16,borderRadius:12,border:"1px solid #eee"}}>
      <h3>1) Choose File & Compute Hash</h3>
      <input type="file" onChange={e=>setFile(e.target.files?.[0]||null)}/>
      <div><button onClick={doHash}>Compute SHA-256</button></div>
      {hash && <p>Hash: <code>{hash}</code></p>}
    </div>

    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginTop:16}}>
      <div style={{background:"#fff",padding:16,borderRadius:12,border:"1px solid #eee"}}>
        <h3>2) Register on Chain</h3>
        <button onClick={doRegister} disabled={!hash}>Register</button>
        <p style={{fontSize:12,color:"#666"}}>Needs MetaMask connected to Ganache (127.0.0.1:7545)</p>
      </div>
      <div style={{background:"#fff",padding:16,borderRadius:12,border:"1px solid #eee"}}>
        <h3>3) Verify</h3>
        <button onClick={doVerify} disabled={!hash}>Verify</button>
      </div>
    </div>

    <div style={{marginTop:16, background:"#fff",padding:16,borderRadius:12,border:"1px solid #eee"}}>
      <h3>Status</h3>
      <p>{status}</p>
      {rec && <pre style={{whiteSpace:"pre-wrap"}}>{JSON.stringify({
        ...rec,
        timeLocal: new Date(rec.timestamp*1000).toLocaleString()
      }, null, 2)}</pre>}
    </div>
  </div>;
}
