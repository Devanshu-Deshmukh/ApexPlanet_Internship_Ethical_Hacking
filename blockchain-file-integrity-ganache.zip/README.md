# Blockchain File Integrity (Ganache GUI Edition)
Run the entire project offline using Ganache Desktop.

## Prereqs
- Ganache GUI (RPC: http://127.0.0.1:7545, Chain ID: 1337)
- Node.js LTS
- MetaMask (import Ganache accounts if needed)

## Steps
1) Open Ganache GUI (Quickstart → it will show RPC 127.0.0.1:7545)
2) Backend deploy:
   ```bash
   cd backend
   npm install
   npm run compile
   npm run deploy:ganache
   ```
   Note the address printed: `FileRegistry deployed to: 0x...`

3) Copy ABI to frontend:
   ```bash
   cp backend/artifacts/contracts/FileRegistry.sol/FileRegistry.json frontend/src/lib/FileRegistry.artifact.json
   ```

4) Frontend run:
   ```bash
   cd frontend
   npm install
   cp .env.example .env
   # edit .env and set VITE_REGISTRY_ADDRESS=0x... (from step 2)
   npm run dev
   ```

5) MetaMask network (Ganache):
   - Network name: Ganache
   - New RPC URL: http://127.0.0.1:7545
   - Chain ID: 1337
   - Currency symbol: ETH
   - Import any Ganache account private key from the GUI to MetaMask (optional).

Use the app: Select file → Hash → Register → Verify.
