require("@nomicfoundation/hardhat-toolbox");

module.exports = {
  solidity: "0.8.20",
  networks: {
    ganache: {
      // Ganache GUI default: http://127.0.0.1:7545
      url: "http://127.0.0.1:7545",
      // Using Ganache GUI default mnemonic so accounts match MetaMask import
      accounts: {
        mnemonic: "test test test test test test test test test test test junk"
      },
      chainId: 1337
    }
  }
};
