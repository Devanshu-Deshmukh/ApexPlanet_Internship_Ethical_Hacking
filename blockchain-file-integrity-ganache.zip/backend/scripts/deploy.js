async function main() {
  const FileRegistry = await ethers.getContractFactory("FileRegistry");
  const registry = await FileRegistry.deploy();
  await registry.deployed();
  console.log("FileRegistry deployed to:", registry.address);
}
main().catch((e)=>{ console.error(e); process.exit(1); });
