# Backend (Hardhat + Ganache)
- Start Ganache GUI (RPC: http://127.0.0.1:7545, chainId 1337)
- In this folder:
  ```bash
  npm install
  npm run compile
  npm run deploy:ganache
  ```
- Copy ABI to frontend:
  ```bash
  cp artifacts/contracts/FileRegistry.sol/FileRegistry.json ../frontend/src/lib/FileRegistry.artifact.json
  ```
- Put the deployed address into `../frontend/.env` as `VITE_REGISTRY_ADDRESS=`
